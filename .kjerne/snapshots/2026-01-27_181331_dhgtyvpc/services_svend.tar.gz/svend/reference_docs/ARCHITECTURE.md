# SVEND System Architecture

## Document History

- **2026-01-21**: Complete architecture revision. MoE reasoner replaced with Synara Bayesian network. This document supersedes all previous architecture decisions.

---

## Executive Summary

SVEND is a tool-augmented reasoning system. Unlike traditional LLM approaches that predict tokens (including tool results), SVEND uses a **Bayesian belief network (Synara)** to select and execute tools deterministically.

**Key insight**: Neural networks hallucinate because they predict. Synara cannot hallucinate tool results because it executes them.

```
Previous Architecture (Failed):
  Input → MoE Reasoner (160M) → Predicts tool results → Wrong answers

New Architecture (Synara):
  Input → LM (parse) → Synara (select+execute tools) → LM (format) → Correct answers
```

**Validation Results (2026-01-21)**:
- MoE Reasoner: 0% accuracy on new arithmetic problems (predicted 15+27=135)
- Synara: 71.7% accuracy on GSM8K with zero training
- Synara tool execution: 95.5% accuracy (calc: 100%, chemistry: 56.5%)

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           SVEND SYSTEM ARCHITECTURE                          │
│                              (Synara-Based)                                  │
└─────────────────────────────────────────────────────────────────────────────┘

    User Request (natural language)
         │
         ▼
    ┌─────────────────────────────────────────────────────────────────────────┐
    │  SAFETY ROUTER (27M)                                                    │
    │  - Binary classifier: safe/unsafe                                       │
    │  - Trained, 100% accuracy on test set                                   │
    │  - Can block requests before any processing                             │
    └───────────────────────────────┬─────────────────────────────────────────┘
                                    │ (if safe)
                                    ▼
    ┌─────────────────────────────────────────────────────────────────────────┐
    │  INPUT LM: Qwen2.5-3B or Phi-3-mini (2-3B params)                       │
    │                                                                          │
    │  Purpose: Parse natural language → structured representation             │
    │  Output:                                                                 │
    │    {                                                                     │
    │      "domain": "chemistry",                                              │
    │      "operation": "stoichiometry",                                       │
    │      "entities": ["salicylic_acid", "10g"],                             │
    │      "question_type": "yield_calculation"                                │
    │    }                                                                     │
    │                                                                          │
    │  This model does NOT reason. It only translates.                         │
    └───────────────────────────────┬─────────────────────────────────────────┘
                                    │
                                    ▼
    ┌─────────────────────────────────────────────────────────────────────────┐
    │  INTUITION MODEL (65M) - Optional conditioning                          │
    │                                                                          │
    │  - Produces 512d conditioning vector                                     │
    │  - Primes Synara's domain beliefs                                        │
    │  - Trained, 93.6% domain classification accuracy                         │
    └───────────────────────────────┬─────────────────────────────────────────┘
                                    │
                                    ▼
    ┌─────────────────────────────────────────────────────────────────────────┐
    │  SYNARA REASONER (Bayesian Network, 1M - 20B nodes)                     │
    │                                                                          │
    │  ┌─────────────────────────────────────────────────────────────────┐    │
    │  │  HIERARCHICAL BELIEF LEVELS                                      │    │
    │  │                                                                   │    │
    │  │  L0: Prior (uniform) ─────────────────────────────────────────┐ │    │
    │  │       │                                                        │ │    │
    │  │       ▼                                                        │ │    │
    │  │  L1: Domain beliefs ──────────────────────────────────────┐   │ │    │
    │  │       │  (math, physics, chemistry, logic, finance...)    │   │ │    │
    │  │       │                                                    │   │ │    │
    │  │       ▼                                                    │   │ │    │
    │  │  L2: Tool beliefs (PRIMARY) ──────────────────────────┐   │   │ │    │
    │  │       │  (calc, sympy, chemistry, physics, z3...)     │   │   │ │    │
    │  │       │                                                │   │   │ │    │
    │  │       ▼                                                │   │   │ │    │
    │  │  L3: Pattern beliefs ─────────────────────────────┐   │   │   │ │    │
    │  │         (specific operation signatures)           │   │   │   │ │    │
    │  │                                                   │   │   │   │ │    │
    │  │  Cascade fallback: L3 uncertain? → L2 → L1 → L0 ──┴───┴───┴───┘ │    │
    │  └─────────────────────────────────────────────────────────────────┘    │
    │                                                                          │
    │  ┌─────────────────────────────────────────────────────────────────┐    │
    │  │  ENERGY STATES                                                   │    │
    │  │                                                                   │    │
    │  │  Energy = 0: High confidence (like ground state electron)        │    │
    │  │  Energy = max: Low confidence (excited state)                    │    │
    │  │                                                                   │    │
    │  │  Success → energy decreases (stabilizes)                         │    │
    │  │  Failure → energy increases (destabilizes)                       │    │
    │  └─────────────────────────────────────────────────────────────────┘    │
    │                                                                          │
    │  ┌─────────────────────────────────────────────────────────────────┐    │
    │  │  BELIEF UPDATES (Beta Distributions)                             │    │
    │  │                                                                   │    │
    │  │  Each (tool, operation) pair has: Beta(α, β)                     │    │
    │  │    - Success: α += 1                                              │    │
    │  │    - Failure: β += 1.5 (learn faster from mistakes)              │    │
    │  │    - Mean success rate: α / (α + β)                               │    │
    │  │    - Confidence: (α + β - 2) / 10                                 │    │
    │  │                                                                   │    │
    │  │  Tool selection: Thompson sampling from Beta distributions        │    │
    │  └─────────────────────────────────────────────────────────────────┘    │
    │                                                                          │
    │  CRITICAL: Synara EXECUTES tools, does not predict results.             │
    │                                                                          │
    └───────────────────────────────┬─────────────────────────────────────────┘
                                    │
                                    ▼
    ┌─────────────────────────────────────────────────────────────────────────┐
    │  TOOL EXECUTION LAYER                                                    │
    │                                                                          │
    │  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐      │
    │  │   calc   │ │  sympy   │ │chemistry │ │ physics  │ │    z3    │      │
    │  │          │ │          │ │          │ │          │ │          │      │
    │  │ 15+27=42 │ │ solve()  │ │ balance  │ │ kinematic│ │ SAT/SMT  │      │
    │  │ 100% acc │ │ diff()   │ │ stoich   │ │ circuits │ │ solver   │      │
    │  │          │ │ integrate│ │ molar    │ │ thermo   │ │          │      │
    │  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘      │
    │                                                                          │
    │  All tools execute in sandboxed environment. 30s timeout.                │
    └───────────────────────────────┬─────────────────────────────────────────┘
                                    │
                                    ▼
    ┌─────────────────────────────────────────────────────────────────────────┐
    │  SYNARA VERIFIER (separate Bayesian network instance)                    │
    │                                                                          │
    │  - Receives SAME input as reasoner                                       │
    │  - Receives SAME intuition conditioning                                  │
    │  - Does NOT see reasoner's intermediate work                             │
    │  - Independently verifies result                                         │
    │  - Can REJECT incorrect solutions                                        │
    │                                                                          │
    │  This is adversarial verification, not rubber-stamping.                  │
    └───────────────────────────────┬─────────────────────────────────────────┘
                                    │
                                    ▼
    ┌─────────────────────────────────────────────────────────────────────────┐
    │  OUTPUT LM: Qwen2.5-1.5B or Phi-3-mini (1-1.5B params)                  │
    │                                                                          │
    │  Purpose: Structured results → minimal prose                             │
    │  Input:                                                                  │
    │    {                                                                     │
    │      "steps": [...],                                                     │
    │      "tool_calls": [{"name": "calc", "input": "10/138.12*180.16",       │
    │                      "result": "13.04"}],                                │
    │      "answer": "13.04 g",                                                │
    │      "verified": true                                                    │
    │    }                                                                     │
    │                                                                          │
    │  Output: "Theoretical yield: 13.04 g aspirin from 10 g salicylic acid." │
    │                                                                          │
    │  Style: Terse, technical, minimal. "Strict Norwegian guy."               │
    │  This model does NOT reason. It only formats.                            │
    └───────────────────────────────┬─────────────────────────────────────────┘
                                    │
                                    ▼
    User Response (formatted answer with reasoning trace)
```

---

## Why Synara Instead of Neural Networks

### The Problem with MoE/Transformer Reasoners

On 2026-01-21, the MoE reasoner (160M params) was tested on arithmetic:

```
Problem: 15 + 27 = ?
MoE Output: 135
Expected: 42

The MoE learned to PREDICT what tool results look like, not execute tools.
```

This is fundamental to how neural networks work:
- They predict the next token based on patterns
- They have no concept of "correct" vs "incorrect"
- They hallucinate confidently because prediction is all they do

### How Synara Differs

| Aspect | Neural Network | Synara |
|--------|---------------|--------|
| Knowledge representation | Distributed in weights | Explicit beliefs |
| Learning | Gradient descent | Bayesian updates |
| Tool interaction | Predicts outputs | Executes tools |
| Uncertainty | Hidden | Explicit (energy states) |
| Explainability | Black box | Traceable decisions |
| Scaling | More parameters (expensive) | More nodes (cheap) |
| Training data | Massive | Traces only |

### Validation Results

```
Synara on GSM8K (2026-01-21):
- Problems attempted: 500
- Accuracy: 71.7% (with ZERO training)
- Tool success rate: 99.9%

Direct tool execution test:
- calc: 100.0% accuracy (62,628 examples)
- chemistry: 56.5% accuracy (7,234 examples)
- Overall: 95.5% accuracy

Beliefs learned (without gradient descent):
  (calc, add): mean=0.99, confidence=1.0
  (calc, multiply): mean=0.99, confidence=1.0
  (calc, divide): mean=0.99, confidence=1.0
  (sympy, solve): mean=0.85, confidence=0.8
```

---

## Component Specifications

### Safety Router (27M)
- **Status**: Trained, deployed
- **Accuracy**: 100% on test set
- **Latency**: <50ms
- **Purpose**: Block unsafe requests before processing

### Input LM (2-3B)
- **Recommended**: Qwen2.5-3B or Phi-3-mini-4k-instruct
- **License**: Apache 2.0 (both)
- **Purpose**: Parse natural language → structured representation
- **NOT for**: Reasoning, answering questions, generating content
- **Training**: Fine-tune on (question, structured_output) pairs

### Intuition Model (65M)
- **Status**: Trained, 93.6% accuracy
- **Output**: 512d conditioning vector
- **Purpose**: Prime Synara's domain beliefs
- **Optional**: Synara can work without it (beliefs self-organize)

### Synara Reasoner
- **Type**: Hierarchical Bayesian belief network
- **Nodes**: 1M minimum, 20B+ supported
- **Memory**: O(nodes), not O(nodes^2)
- **Inference**: O(1) per belief lookup
- **Training**: None required (beliefs update at inference time)
- **Prior injection**: Feed traces → beliefs initialize

### Synara Verifier
- **Type**: Same architecture as reasoner
- **Independence**: Does not share beliefs with reasoner
- **Purpose**: Adversarial verification
- **Can**: Reject incorrect solutions

### Output LM (1-1.5B)
- **Recommended**: Qwen2.5-1.5B or fine-tuned Phi-3
- **License**: Apache 2.0
- **Purpose**: Format results → minimal prose
- **Style**: Terse, technical, direct
- **NOT for**: Reasoning, elaboration, pleasantries

### Tool Layer
| Tool | Purpose | Accuracy | Status |
|------|---------|----------|--------|
| calc | Safe arithmetic | 100% | Implemented |
| sympy | Symbolic math | ~85% | Implemented |
| chemistry | Reactions, stoichiometry | 56.5% | Needs improvement |
| physics | Kinematics, circuits | ~90% | Implemented |
| z3 | Constraint solving | - | Needs implementation |
| python | General computation | - | Needs sandboxing |

---

## Hardware Requirements

### Development (RTX 3090)
```
Component         VRAM      RAM
─────────────────────────────────
Input LM (3B)     6 GB      -
Synara (10M)      -         1 GB
Output LM (1.5B)  3 GB      -
Tools             -         2 GB
─────────────────────────────────
Total             ~10 GB    ~3 GB

Fits comfortably on RTX 3090 (24GB)
```

### Production (Target)
```
Single A10G (24GB) or 2x RTX 4090:
- Input LM: 6 GB
- Synara: 1-4 GB (depending on node count)
- Output LM: 3 GB
- Buffer: 10+ GB for batch processing
```

---

## Data Flow

### Request Processing

```
1. Request arrives at API Gateway
2. Safety Router check (block if unsafe)
3. Input LM parses to structured format
4. Intuition model produces conditioning (optional)
5. Synara Reasoner:
   a. Receives structured input
   b. Selects tool via Thompson sampling from beliefs
   c. EXECUTES tool (deterministic result)
   d. Updates beliefs based on success/failure
   e. Repeats until answer reached
6. Synara Verifier independently checks result
7. If verified: Output LM formats response
8. If rejected: Reasoner retries or returns uncertainty
9. Response returned to user
```

### Belief Updates (No Training Required)

```python
# This is ALL that happens when Synara "learns":

class BetaBelief:
    def __init__(self):
        self.alpha = 1.0  # successes
        self.beta = 1.0   # failures

    def update(self, success: bool):
        if success:
            self.alpha += 1.0
        else:
            self.beta += 1.5  # learn faster from mistakes

    @property
    def mean(self) -> float:
        return self.alpha / (self.alpha + self.beta)

    def sample(self) -> float:
        # Thompson sampling for exploration/exploitation
        return random.betavariate(self.alpha, self.beta)
```

No gradients. No backprop. No GPU for "training."

---

## Prior Injection ("Training")

Instead of training Synara with gradient descent, we **inject priors** from traces:

```python
# Load expert traces
traces = load_traces("gsm8k_traces.jsonl")

# For each trace, extract what worked
for trace in traces:
    for tool_call in trace.tool_calls:
        if tool_call.succeeded:
            synara.beliefs[(tool_call.tool, tool_call.operation)].update(True)
        else:
            synara.beliefs[(tool_call.tool, tool_call.operation)].update(False)

# Done. Synara now has priors from expert behavior.
```

This is why Synara achieved 71.7% accuracy on GSM8K with "zero training" - it was actually using well-initialized beliefs from traces.

---

## Monitoring & Observability

### Synara-Specific Metrics
```
- belief_confidence: Mean confidence across active beliefs
- energy_level: Current energy state (lower = more stable)
- tool_selection_entropy: How uncertain tool selection is
- cascade_depth: How often falling back to higher levels
- verification_rejection_rate: How often verifier rejects
```

### Alerts
```
- energy_level > 0.7 sustained: Synara is unstable
- verification_rejection_rate > 0.3: Reasoner producing bad results
- cascade_depth consistently at L0: Beliefs not forming
```

---

## Security Considerations

### Tool Sandboxing
- All tools execute in isolated containers
- No network access from tool environment
- 30-second timeout per tool call
- Memory limit: 1GB per tool execution
- No persistent state between calls

### Synara Integrity
- Beliefs cannot be directly modified by user input
- Tool results are validated before belief updates
- Energy state prevents runaway confidence

---

## Cost Model

### Compute Costs
| Component | GPU Cost/month |
|-----------|---------------|
| Input LM (3B) | Shared |
| Synara | CPU only |
| Output LM (1.5B) | Shared |
| **Total GPU** | $300-500 (A10G) |

### Why Cheaper Than Pure LLM
- Synara runs on CPU (belief lookups, not matrix multiply)
- LLMs only handle I/O (parsing, formatting)
- Reasoning happens without GPU
- Scaling Synara = adding nodes, not parameters

---

## Migration Plan

### Phase 1: Validate (Current)
- [x] Prove Synara works on GSM8K
- [x] Measure tool execution accuracy
- [ ] Implement Z3 tool
- [ ] Improve chemistry tool accuracy

### Phase 2: Integrate
- [ ] Wire Input LM → Synara → Output LM
- [ ] Train Input LM on structured extraction
- [ ] Fine-tune Output LM on terse style
- [ ] Integrate with existing Safety Router

### Phase 3: Deploy
- [ ] Replace MoE reasoner with Synara
- [ ] A/B test against old architecture
- [ ] Monitor belief formation in production
- [ ] Iterate on tool implementations

---

## Appendix: Why This Matters

### What We Tried First (Failed)

```
MoE Reasoner (160M params):
- Trained on GSM8K traces
- Learned to generate text that LOOKS LIKE tool calls
- Predicted tool results instead of executing them
- Result: 0% accuracy on new problems
- Gate collapsed: 8.48% Synara contribution
```

### What We Discovered

Synara was built in 2024 for infrastructure (OS-level belief tracking). It was never intended as a reasoning system. However:

1. It maintains explicit hypotheses (not distributed weights)
2. It updates via Bayesian inference (not gradient descent)
3. It knows when it's uncertain (energy states)
4. It executes rather than predicts

These properties make it ideal for tool-augmented reasoning where **correctness matters**.

### The Fundamental Insight

```
Neural networks are function approximators.
Synara is an epistemology engine.

NNs ask: "What token usually comes next?"
Synara asks: "Which tool has worked for this type of problem?"

When you need to know that 15 + 27 = 42 (not 135),
you need execution, not prediction.
```

---

## References

- `k/kjerne/r_and_d/tiny_models/synara_trial.py` - Validation on GSM8K
- `k/kjerne/r_and_d/tiny_models/synara_multidomain_trial.py` - Multi-domain stress test
- `k/kjerne/r_and_d/tiny_models/synara_integrated.py` - Full Synara implementation
- `k/kjerne/r_and_d/synara_data/SURVIVE-001/` - Original survival experiments
- `k/kjerne/r_and_d/tiny_models/master_dataset.jsonl` - 156K traces across 13 domains
