"""Forge - Synthetic Data Generation."""

default_app_config = "forge.apps.ForgeConfig"
