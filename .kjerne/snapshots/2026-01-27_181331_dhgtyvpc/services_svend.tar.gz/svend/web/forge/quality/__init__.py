"""Quality validation for generated data."""

from .validator import validate_records

__all__ = ["validate_records"]
