#!/bin/bash
# Production startup script for Svend

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Activate virtual environment
source /home/eric/Desktop/svend_transfer/.venv/bin/activate

# Collect static files
echo "Collecting static files..."
python manage.py collectstatic --noinput

# Apply any pending migrations
echo "Applying migrations..."
python manage.py migrate --noinput

# Start gunicorn
echo "Starting gunicorn on port 8000..."
exec gunicorn svend.wsgi:application \
    --bind 0.0.0.0:8000 \
    --workers 2 \
    --threads 4 \
    --worker-class gthread \
    --timeout 120 \
    --keep-alive 5 \
    --access-logfile /tmp/gunicorn_access.log \
    --error-logfile /tmp/gunicorn_error.log \
    --capture-output \
    --enable-stdio-inheritance
