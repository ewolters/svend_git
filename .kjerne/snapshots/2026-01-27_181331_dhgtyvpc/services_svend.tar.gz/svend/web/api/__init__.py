"""REST API for Svend."""

default_app_config = "api.apps.ApiConfig"
