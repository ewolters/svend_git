"""API URL configuration."""

from django.urls import path

from . import views

app_name = "api"

urlpatterns = [
    # Health check
    path("health/", views.health, name="health"),

    # User
    path("user/", views.user_info, name="user_info"),

    # Conversations
    path("conversations/", views.conversations, name="conversations"),
    path("conversations/<uuid:conversation_id>/", views.conversation_detail, name="conversation_detail"),

    # Chat
    path("chat/", views.chat, name="chat"),

    # Sharing
    path("share/", views.share_conversation, name="share"),

    # Feedback / Training data collection
    path("messages/<uuid:message_id>/flag/", views.flag_message, name="flag_message"),

    # Monitoring
    path("stats/traces/", views.trace_stats, name="trace_stats"),
    path("stats/flywheel/", views.flywheel_stats, name="flywheel_stats"),

    # Auth
    path("register/", views.register, name="register"),
]
