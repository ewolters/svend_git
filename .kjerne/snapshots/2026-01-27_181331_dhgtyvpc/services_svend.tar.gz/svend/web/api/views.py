"""API views."""

import logging
import random
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.response import Response

from chat.models import Conversation, Message, SharedConversation, TraceLog, TrainingCandidate
from inference import process_query
from inference.flywheel import get_flywheel, FlywheelResult

from .serializers import (
    ConversationSerializer,
    ConversationListSerializer,
    MessageSerializer,
    ChatInputSerializer,
    ShareSerializer,
)

logger = logging.getLogger(__name__)

# Correctness gate thresholds
VERIFICATION_CONFIDENCE_THRESHOLD = 0.3  # Below this = low confidence
RANDOM_SAMPLE_RATE = 0.05  # 5% random sampling for training data


@api_view(["GET"])
@permission_classes([AllowAny])
def health(request):
    """Health check endpoint."""
    return Response({"status": "ok", "service": "svend"})


@api_view(["GET"])
@permission_classes([IsAuthenticated])
def conversations(request):
    """List user's conversations."""
    convos = Conversation.objects.filter(user=request.user)
    serializer = ConversationListSerializer(convos, many=True)
    return Response(serializer.data)


@api_view(["GET", "DELETE"])
@permission_classes([IsAuthenticated])
def conversation_detail(request, conversation_id):
    """Get or delete a specific conversation."""
    try:
        convo = Conversation.objects.get(id=conversation_id, user=request.user)
    except Conversation.DoesNotExist:
        return Response(
            {"error": "Conversation not found"},
            status=status.HTTP_404_NOT_FOUND,
        )

    if request.method == "DELETE":
        convo.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

    serializer = ConversationSerializer(convo)
    return Response(serializer.data)


@api_view(["POST"])
@permission_classes([IsAuthenticated])
def chat(request):
    """Send a message and get a response.

    Includes:
    - Full trace logging for diagnostics
    - Fail-closed correctness gate
    - Training candidate collection
    """
    serializer = ChatInputSerializer(data=request.data)
    if not serializer.is_valid():
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    user = request.user
    message_text = serializer.validated_data["message"]
    conversation_id = serializer.validated_data.get("conversation_id")

    # Check rate limit
    if not user.can_query():
        return Response(
            {
                "error": "Daily query limit reached",
                "limit": user.daily_limit,
                "tier": user.tier,
            },
            status=status.HTTP_429_TOO_MANY_REQUESTS,
        )

    # Get or create conversation
    if conversation_id:
        try:
            conversation = Conversation.objects.get(id=conversation_id, user=user)
        except Conversation.DoesNotExist:
            return Response(
                {"error": "Conversation not found"},
                status=status.HTTP_404_NOT_FOUND,
            )
    else:
        conversation = Conversation.objects.create(user=user)

    # Save user message
    user_message = Message.objects.create(
        conversation=conversation,
        role=Message.Role.USER,
        content=message_text,
    )

    # Initialize trace log
    trace_log = TraceLog(
        input_text=message_text,
        user_id=user.id,
    )

    # Process through pipeline with flywheel
    gate_passed = True
    gate_reason = ""
    fallback_used = False
    final_response = ""
    flywheel_result = None
    visualizations = []

    # Get mode preference from request (default: auto)
    mode = serializer.validated_data.get("mode", "auto")

    try:
        # Get result from appropriate pipeline
        result = process_query(message_text, mode=mode)

        # Capture visualizations from coder mode
        if hasattr(result, 'visualizations') and result.visualizations:
            visualizations = result.visualizations

        # Handle cognition pipeline (all modes including EXECUTIVE)
        if result.pipeline_type == "cognition":
            trace_log.safety_passed = not result.blocked
            trace_log.domain = result.selected_mode or result.domain or "cognition"
            trace_log.difficulty = result.difficulty
            trace_log.reasoning_trace = result.reasoning_trace
            trace_log.tool_calls = result.tool_calls
            trace_log.verified = result.verified
            trace_log.verification_confidence = result.verification_confidence
            trace_log.response = result.response
            trace_log.total_time_ms = result.inference_time_ms

            if result.blocked:
                gate_passed = False
                gate_reason = f"Pipeline error: {result.block_reason}"
                final_response = "I couldn't process that request."
            elif result.success or result.response:
                gate_passed = True
                gate_reason = f"Cognition mode: {result.selected_mode}"
                final_response = result.response
            else:
                gate_passed = False
                gate_reason = "No response generated"
                final_response = result.response or "Could not generate response."

            trace_log.gate_passed = gate_passed
            trace_log.gate_reason = gate_reason

        # Legacy coder mode handling
        elif result.pipeline_type == "coder":
            trace_log.safety_passed = not result.blocked
            trace_log.domain = result.domain or "computation"
            trace_log.difficulty = result.difficulty
            trace_log.reasoning_trace = result.reasoning_trace
            trace_log.tool_calls = result.tool_calls
            trace_log.verified = result.verified
            trace_log.verification_confidence = result.verification_confidence
            trace_log.response = result.response
            trace_log.total_time_ms = result.inference_time_ms

            if result.blocked:
                gate_passed = False
                gate_reason = f"Coder error: {result.block_reason}"
                final_response = "I couldn't execute that code."
            elif result.verified:
                gate_passed = True
                gate_reason = "Code executed successfully"
                final_response = result.response
            else:
                gate_passed = False
                gate_reason = "Code execution failed"
                final_response = result.response or "Code execution failed."

            trace_log.gate_passed = gate_passed
            trace_log.gate_reason = gate_reason

        else:
            # Synara mode - process through flywheel (may escalate to Opus)
            flywheel = get_flywheel()
            flywheel_result = flywheel.process(
                query=message_text,
                synara_result=result,
                user_id=str(user.id),
                allow_escalation=True,  # Enable Opus escalation
            )

            # Update trace log with results
            trace_log.safety_passed = not result.blocked
            trace_log.domain = result.domain or ""
            trace_log.difficulty = result.difficulty
            trace_log.reasoning_trace = flywheel_result.final_trace or result.reasoning_trace
            trace_log.tool_calls = result.tool_calls
            trace_log.verified = result.verified
            trace_log.verification_confidence = result.verification_confidence
            trace_log.response = flywheel_result.final_response
            trace_log.total_time_ms = flywheel_result.total_time_ms or result.inference_time_ms

            # === FAIL-CLOSED CORRECTNESS GATE ===
            if result.blocked:
                # Safety blocked - use block reason
                gate_passed = False
                gate_reason = f"Safety blocked: {result.block_reason}"
                final_response = "I can't help with that request."

            elif flywheel_result.used_opus:
                # Opus was used - flywheel handled it
                gate_passed = flywheel_result.synara_success or bool(flywheel_result.opus_response)
                gate_reason = f"Escalated to Opus: {flywheel_result.escalation_reason.value if flywheel_result.escalation_reason else 'unknown'}"
                fallback_used = True
                final_response = flywheel_result.final_response

            elif not flywheel_result.synara_success:
                # Synara failed and no Opus available
                gate_passed = False
                gate_reason = "Synara failed, no escalation available"
                fallback_used = True
                final_response = "Could not solve. Try rephrasing."

            elif flywheel_result.synara_confidence < VERIFICATION_CONFIDENCE_THRESHOLD:
                # Low confidence but Synara succeeded
                gate_passed = True  # Still pass but mark as low confidence
                gate_reason = f"Low confidence: {flywheel_result.synara_confidence:.2f}"
                final_response = flywheel_result.final_response

            elif not flywheel_result.final_response or len(flywheel_result.final_response.strip()) < 1:
                # Empty response
                gate_passed = False
                gate_reason = "Empty response"
                fallback_used = True
                final_response = "Could not generate response."

            else:
                # Gate passed - use flywheel response
                final_response = flywheel_result.final_response

            trace_log.gate_passed = gate_passed
            trace_log.gate_reason = gate_reason
            trace_log.fallback_used = fallback_used

    except Exception as e:
        # Pipeline error - fail closed
        logger.exception(f"Pipeline error for user {user.id}")
        trace_log.error_stage = "pipeline"
        trace_log.error_message = str(e)
        trace_log.gate_passed = False
        trace_log.gate_reason = f"Pipeline error: {type(e).__name__}"

        gate_passed = False
        fallback_used = True
        final_response = "I encountered an error processing your request. Please try again."

        # Create result-like object for the message
        class ErrorResult:
            response = final_response
            domain = ""
            difficulty = None
            verified = None
            verification_confidence = None
            blocked = False
            block_reason = ""
            reasoning_trace = None
            tool_calls = None
            inference_time_ms = None
            formatted_trace = None
        result = ErrorResult()

    # Save assistant response
    assistant_message = Message.objects.create(
        conversation=conversation,
        role=Message.Role.ASSISTANT,
        content=final_response,
        domain=result.domain or "",
        difficulty=result.difficulty,
        verified=result.verified,
        verification_confidence=result.verification_confidence,
        blocked=result.blocked,
        block_reason=result.block_reason or "",
        reasoning_trace=result.reasoning_trace,
        tool_calls=result.tool_calls,
        inference_time_ms=result.inference_time_ms,
    )

    # Save trace log linked to message
    trace_log.message = assistant_message
    trace_log.save()

    # === TRAINING CANDIDATE COLLECTION ===
    should_collect = False
    candidate_type = None

    if not gate_passed:
        if trace_log.error_stage:
            should_collect = True
            candidate_type = TrainingCandidate.CandidateType.ERROR
        elif result.verification_confidence is not None and result.verification_confidence < VERIFICATION_CONFIDENCE_THRESHOLD:
            should_collect = True
            candidate_type = TrainingCandidate.CandidateType.LOW_CONFIDENCE
        elif result.verified is False:
            should_collect = True
            candidate_type = TrainingCandidate.CandidateType.VERIFICATION_FAILED
    elif random.random() < RANDOM_SAMPLE_RATE:
        # Random sampling of successful responses for quality monitoring
        should_collect = True
        candidate_type = TrainingCandidate.CandidateType.RANDOM_SAMPLE

    if should_collect and candidate_type:
        TrainingCandidate.objects.create(
            trace_log=trace_log,
            candidate_type=candidate_type,
            input_text=message_text,
            domain=result.domain or "",
            difficulty=result.difficulty,
            reasoning_trace=result.reasoning_trace,
            model_response=result.response or "",
            verification_confidence=result.verification_confidence,
            error_type=trace_log.error_stage if trace_log.error_stage else "",
        )
        logger.info(f"Created training candidate: {candidate_type} for input: {message_text[:50]}...")

    # Update conversation title if first message
    if conversation.messages.count() == 2:
        conversation.generate_title()

    # Increment user query count
    user.increment_queries()

    # Build response with formatted trace if available
    response_data = {
        "conversation_id": str(conversation.id),
        "user_message": MessageSerializer(user_message).data,
        "assistant_message": MessageSerializer(assistant_message).data,
        "pipeline_type": result.pipeline_type if hasattr(result, 'pipeline_type') else "synara",
    }

    # Include cognition mode info
    if hasattr(result, 'selected_mode') and result.selected_mode:
        response_data["selected_mode"] = result.selected_mode
    if hasattr(result, 'mode_scores') and result.mode_scores:
        response_data["mode_scores"] = result.mode_scores
    if hasattr(result, 'confidence') and result.confidence:
        response_data["confidence"] = result.confidence

    # Include formatted trace for frontend rendering (KaTeX, visualizations)
    if hasattr(result, 'formatted_trace') and result.formatted_trace:
        response_data["formatted_trace"] = result.formatted_trace

    # Include code and visualizations from coder/executive mode
    if hasattr(result, 'code') and result.code:
        response_data["code"] = result.code
    if visualizations:
        response_data["visualizations"] = visualizations  # Base64 PNGs

    # Include execution outputs for executive mode
    if hasattr(result, 'execution_outputs') and result.execution_outputs:
        response_data["execution_outputs"] = result.execution_outputs
    if hasattr(result, 'execution_errors') and result.execution_errors:
        response_data["execution_errors"] = result.execution_errors
    if hasattr(result, 'tools_used') and result.tools_used:
        response_data["tools_used"] = result.tools_used

    # Include flywheel metadata
    if flywheel_result:
        response_data["flywheel"] = {
            "used_opus": flywheel_result.used_opus,
            "synara_confidence": flywheel_result.synara_confidence,
            "escalation_reason": flywheel_result.escalation_reason.value if flywheel_result.escalation_reason else None,
        }

    return Response(response_data)


@api_view(["POST"])
@permission_classes([IsAuthenticated])
def share_conversation(request):
    """Create a shareable link for a conversation."""
    serializer = ShareSerializer(data=request.data)
    if not serializer.is_valid():
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    try:
        conversation = Conversation.objects.get(
            id=serializer.validated_data["conversation_id"],
            user=request.user,
        )
    except Conversation.DoesNotExist:
        return Response(
            {"error": "Conversation not found"},
            status=status.HTTP_404_NOT_FOUND,
        )

    # Create or get share
    share, created = SharedConversation.objects.get_or_create(
        conversation=conversation,
    )

    return Response({
        "share_id": str(share.id),
        "url": f"/chat/shared/{share.id}/",
    })


@api_view(["GET"])
@permission_classes([IsAuthenticated])
def user_info(request):
    """Get current user info and usage."""
    user = request.user
    return Response({
        "email": user.email,
        "tier": user.tier,
        "queries_today": user.queries_today,
        "daily_limit": user.daily_limit,
        "subscription_active": user.subscription_active,
    })


@api_view(["POST"])
@permission_classes([IsAuthenticated])
def flag_message(request, message_id):
    """Flag a message as problematic for training data collection."""
    try:
        message = Message.objects.get(id=message_id)
        # Verify user owns this conversation
        if message.conversation.user != request.user:
            return Response(
                {"error": "Not authorized"},
                status=status.HTTP_403_FORBIDDEN,
            )
    except Message.DoesNotExist:
        return Response(
            {"error": "Message not found"},
            status=status.HTTP_404_NOT_FOUND,
        )

    reason = request.data.get("reason", "")

    # Get or create trace log
    trace_log = getattr(message, 'trace_log', None)
    if not trace_log:
        # Create minimal trace log for older messages
        trace_log = TraceLog.objects.create(
            message=message,
            input_text=message.conversation.messages.filter(
                role=Message.Role.USER,
                created_at__lt=message.created_at
            ).last().content if message.role == Message.Role.ASSISTANT else message.content,
            user_id=request.user.id,
            response=message.content,
        )

    # Create training candidate
    candidate, created = TrainingCandidate.objects.get_or_create(
        trace_log=trace_log,
        candidate_type=TrainingCandidate.CandidateType.USER_FLAGGED,
        defaults={
            "input_text": trace_log.input_text,
            "domain": message.domain or "",
            "difficulty": message.difficulty,
            "reasoning_trace": message.reasoning_trace,
            "model_response": message.content,
            "verification_confidence": message.verification_confidence,
            "reviewer_notes": f"User flagged: {reason}",
        }
    )

    if not created:
        # Update existing with additional flag reason
        candidate.reviewer_notes += f"\nAdditional flag: {reason}"
        candidate.save()

    logger.info(f"Message {message_id} flagged by user {request.user.id}: {reason}")

    return Response({"status": "flagged", "candidate_id": str(candidate.id)})


@api_view(["GET"])
@permission_classes([AllowAny])
def trace_stats(request):
    """Get trace logging statistics (for monitoring dashboard)."""
    from django.db.models import Count, Avg
    from django.utils import timezone
    from datetime import timedelta

    # Last 24 hours
    since = timezone.now() - timedelta(hours=24)

    total = TraceLog.objects.filter(created_at__gte=since).count()
    gate_passed = TraceLog.objects.filter(created_at__gte=since, gate_passed=True).count()
    gate_failed = TraceLog.objects.filter(created_at__gte=since, gate_passed=False).count()
    errors = TraceLog.objects.filter(created_at__gte=since).exclude(error_stage="").count()

    avg_time = TraceLog.objects.filter(
        created_at__gte=since,
        total_time_ms__isnull=False
    ).aggregate(avg=Avg('total_time_ms'))['avg']

    # Domain breakdown
    domains = TraceLog.objects.filter(
        created_at__gte=since
    ).values('domain').annotate(count=Count('id')).order_by('-count')[:10]

    # Training candidates
    candidates = TrainingCandidate.objects.filter(created_at__gte=since)
    candidate_counts = {
        "total": candidates.count(),
        "pending": candidates.filter(status=TrainingCandidate.Status.PENDING).count(),
        "by_type": dict(
            candidates.values('candidate_type').annotate(count=Count('id')).values_list('candidate_type', 'count')
        ),
    }

    return Response({
        "period": "24h",
        "total_requests": total,
        "gate_passed": gate_passed,
        "gate_failed": gate_failed,
        "error_count": errors,
        "avg_inference_time_ms": round(avg_time, 1) if avg_time else None,
        "pass_rate": round(gate_passed / total * 100, 1) if total > 0 else 0,
        "domains": list(domains),
        "training_candidates": candidate_counts,
    })


@api_view(["GET"])
@permission_classes([AllowAny])
def flywheel_stats(request):
    """Get flywheel statistics (for monitoring)."""
    flywheel = get_flywheel()
    stats = flywheel.get_stats()

    # Add pattern analysis if requested
    if request.query_params.get('analyze') == 'true':
        stats['patterns'] = flywheel.analyze_patterns()

    return Response(stats)


@api_view(["POST"])
@permission_classes([AllowAny])
def register(request):
    """Register a new user.

    Requires invite code when SVEND_REQUIRE_INVITE=true (default for alpha).
    """
    from django.contrib.auth import get_user_model
    from accounts.models import InviteCode
    from core.config import get_settings

    settings = get_settings()
    User = get_user_model()

    username = request.data.get("username", "").strip()
    email = request.data.get("email", "").strip()
    password = request.data.get("password", "")
    invite_code = request.data.get("invite_code", "").strip().upper()

    # Validation
    if not username or len(username) < 3:
        return Response(
            {"error": "Username must be at least 3 characters"},
            status=status.HTTP_400_BAD_REQUEST,
        )

    if not password or len(password) < 8:
        return Response(
            {"error": "Password must be at least 8 characters"},
            status=status.HTTP_400_BAD_REQUEST,
        )

    if User.objects.filter(username=username).exists():
        return Response(
            {"error": "Username already taken"},
            status=status.HTTP_400_BAD_REQUEST,
        )

    if email and User.objects.filter(email=email).exists():
        return Response(
            {"error": "Email already registered"},
            status=status.HTTP_400_BAD_REQUEST,
        )

    # Check invite code if required
    invite = None
    if settings.require_invite:
        if not invite_code:
            return Response(
                {"error": "Invite code required for alpha access"},
                status=status.HTTP_400_BAD_REQUEST,
            )

        try:
            invite = InviteCode.objects.get(code=invite_code)
            if not invite.is_valid:
                return Response(
                    {"error": "Invite code is expired or fully used"},
                    status=status.HTTP_400_BAD_REQUEST,
                )
        except InviteCode.DoesNotExist:
            return Response(
                {"error": "Invalid invite code"},
                status=status.HTTP_400_BAD_REQUEST,
            )

    # Create user
    user = User.objects.create_user(
        username=username,
        email=email,
        password=password,
        tier=User.Tier.BETA,  # Alpha users get beta tier limits
    )

    # Mark invite as used
    if invite:
        invite.use(user)

    logger.info(f"New user registered: {username} (invite: {invite_code or 'none'})")

    return Response({
        "status": "registered",
        "username": username,
        "tier": user.tier,
        "message": "Welcome to Svend alpha!",
    }, status=status.HTTP_201_CREATED)
