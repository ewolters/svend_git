"""Chat conversations and messages."""

default_app_config = "chat.apps.ChatConfig"
