"""User accounts and authentication."""

default_app_config = "accounts.apps.AccountsConfig"
