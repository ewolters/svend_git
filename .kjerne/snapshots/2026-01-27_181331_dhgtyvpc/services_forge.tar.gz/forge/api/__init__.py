"""FastAPI endpoints for Forge."""

# TODO: Implement API
# POST /api/v1/generate - Create generation job
# GET /api/v1/jobs/{id} - Check job status
# GET /api/v1/jobs/{id}/result - Download results

__all__ = []
