"""Schema definitions for Forge."""

# TODO: Implement schemas
# - TabularSchema: Field types, constraints, distributions
# - TextSchema: Domain, style, length constraints

__all__ = []
