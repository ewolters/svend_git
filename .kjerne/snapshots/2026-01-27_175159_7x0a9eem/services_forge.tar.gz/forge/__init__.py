"""
Forge - Synthetic Data Generation API

Generate high-quality synthetic data for ML training:
- Tabular data (structured records with schema definition)
- Text data (conversations, reviews, support tickets)

Quality tiers:
- Standard: Schema validation + basic stats
- Premium: Full pipeline validation + Synara verification

Domains:
- E-commerce (products, orders, reviews, user profiles)
- Customer service (tickets, chat conversations)

Usage:
    from forge import ForgeGenerator, TabularSchema

    schema = TabularSchema({
        "product_name": {"type": "string"},
        "price": {"type": "float", "constraints": {"min": 0.01, "max": 10000}},
        "category": {"type": "category", "values": ["electronics", "clothing"]},
    })

    generator = ForgeGenerator()
    df = generator.generate(schema, n=1000)
"""

__version__ = "0.1.0"

# Placeholder imports - to be implemented
# from .generators import TabularGenerator, TextGenerator
# from .schemas import TabularSchema, TextSchema
# from .api import app

__all__ = [
    "__version__",
]
